package me.kevingleason.phue;

import android.app.Activity;
import android.media.MediaPlayer;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import com.pubnub.api.Callback;
import com.pubnub.api.Pubnub;
import com.pubnub.api.PubnubError;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.*;
import android.os.Vibrator;


public class MainActivity extends Activity {
    public static final int COLOR_RED   = 0;
    //public static final int COLOR_BLUE  = 1;
    public static final int COLOR_GREEN = 2;

    SeekBar mRedSeek, mGreenSeek ;
    LinearLayout mRGBValueHolder;
    TextView txtView,txtView1,txtView2;
    JSONObject jsonObj=null;

    private Pubnub mPubNub;
    public static final String PUBLISH_KEY = "pub-c-49d05748-917f-409f-a425-8f0bc9e281c0";
    public static final String SUBSCRIBE_KEY = "sub-c-1ac5c480-fab9-11e8-9488-9e80330262eb";
    public static final String CHANNEL = "phue";
    public static final String CHANNEL1 = "deepak";

    private long lastUpdate = System.currentTimeMillis();
    private boolean pHueOn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initPubNub();

        // Get Seek Bars
        mRedSeek   = (SeekBar) findViewById(R.id.red_seek);
        mGreenSeek = (SeekBar) findViewById(R.id.green_seek);
       // mBlueSeek  = (SeekBar) findViewById(R.id.blue_seek);
        mRGBValueHolder = (LinearLayout) findViewById(R.id.rgb_value_holder);

        /////////////////////////creating for susbcription

        txtView = (TextView) findViewById(R.id.text_id);
        txtView1 = (TextView) findViewById(R.id.text_id1);
        txtView2 = (TextView) findViewById(R.id.text_id2);


        ////////////////////////////

        // Setup Seek Bars
        setupSeekBar(mRedSeek,   COLOR_RED);
        setupSeekBar(mGreenSeek, COLOR_GREEN);
        //setupSeekBar(mBlueSeek,  COLOR_BLUE);
        MediaPlayer doorbell= MediaPlayer.create(MainActivity.this,R.raw.doorbell);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void initPubNub(){
        this.mPubNub = new Pubnub(
                PUBLISH_KEY,
                SUBSCRIBE_KEY
        );
        this.mPubNub.setUUID("AndroidPHue");
        subscribe();
    }

    public void publish(int red, int green){
        JSONObject js = new JSONObject();
        try {
            js.put("RED",   red);
            js.put("GREEN", green);
           // js.put("BLUE",  blue);
        } catch (JSONException e) { e.printStackTrace(); }

        Callback callback = new Callback() {
            public void successCallback(String channel, Object response) {
                Log.d("PUBNUB",response.toString());
            }
            public void errorCallback(String channel, PubnubError error) {
                Log.d("PUBNUB",error.toString());
            }
        };
        this.mPubNub.publish(CHANNEL, js, callback);
    }


    public void subscribe(){
        try {
            this.mPubNub.subscribe(CHANNEL1, new Callback() {
                @Override
                public void connectCallback(String channel1, Object message) {
                    Log.d("PUBNUB","SUBSCRIBE : CONNECT on channel1:" + channel1
                            + " : " + message.getClass() + " : "
                            + message.toString());
                }

                @Override
                public void disconnectCallback(String channel1, Object message) {
                    Log.d("PUBNUB","SUBSCRIBE : DISCONNECT on channel1:" + channel1
                            + " : " + message.getClass() + " : "
                            + message.toString());
                }

                public void reconnectCallback(String channel1, Object message) {
                    Log.d("PUBNUB","SUBSCRIBE : RECONNECT on channel1:" + channel1
                            + " : " + message.getClass() + " : "
                            + message.toString());
                }

                @Override
                public void successCallback(String channel1, Object message) {


                    try {
                        jsonObj = new JSONObject(message.toString());
                        Log.d("PUBNUB","SUBSCRIBED Message : " + channel1 + " : "
                                + message.getClass() + " : " + message.toString()+ " MOTION:::" + jsonObj.getBoolean("motion"));


                       // final TextView textViewToChange = (TextView) findViewById(R.id.text_id);
                        String tmp=jsonObj.getString("temp");
                        String hum=jsonObj.getString("humi");
                        txtView.setText("Temp: " + tmp + ", Humi: " + hum);

                        if(jsonObj.getBoolean("motion")){

                            Vibrator mVibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                            // Vibrate for 300 milliseconds
                            mVibrator.vibrate(1000);
                            txtView1.setText("Motion Detected");
                            MediaPlayer motion= MediaPlayer.create(MainActivity.this,R.raw.motion);
                            motion.start();

                        }
                        else{
                            txtView1.setText(" ");

                        }
                        if(jsonObj.getBoolean("visitor")){

                            txtView2.setText("Visitor Arrived");
                           MediaPlayer doorbell= MediaPlayer.create(MainActivity.this,R.raw.doorbell);
                           doorbell.start();

                        }
                        else{
                            txtView2.setText(" ");
                        }



                    } catch (JSONException e) {
                        e.printStackTrace();
                    }



                }

                @Override
                public void errorCallback(String channel1, PubnubError error) {
                    Log.d("PUBNUB","SUBSCRIBE : ERROR on channel1 " + channel1
                            + " : " + error.toString());
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setupSeekBar(SeekBar seekBar, final int colorID){
        seekBar.setMax(100);        // Seek bar values goes 0-255
        seekBar.setProgress(100);   // Set the knob to 255 to start
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                publish(mRedSeek.getProgress(), mGreenSeek.getProgress());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                publish(mRedSeek.getProgress(), mGreenSeek.getProgress());
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                TextView colorValueText;
                switch (colorID){  // Get the TextView identified by the colorID
                    case COLOR_RED:
                        colorValueText = (TextView)findViewById(R.id.red_value);
                        break;
                    case COLOR_GREEN:
                        colorValueText = (TextView) findViewById(R.id.green_value);
                        break;
                    default:
                        Log.e("SetupSeek","Invalid color.");
                        return;
                }
                colorValueText.setText(String.valueOf(progress));  // Update the 0-255 text
                int red   = mRedSeek.getProgress();     // Get Red value 0-255
                int green = mGreenSeek.getProgress();   // Get Grn value 0-255
                //int blue  = mBlueSeek.getProgress();    // Get Blu value 0-255
                updateRGBViewHolderColor(red, green); // Change the background of the viewholder

                long now = System.currentTimeMillis();    // Only allow 1 pub every 100 milliseconds
                if (now - lastUpdate > 100 && fromUser) { // Threshold and only send when user sliding
                    lastUpdate = now;
                    publish(red, green);          // Stream RGB values to the Pi
                }
            }
        });
    }

    public void lightOff(View view){
        publish(0, 0);
        setRGBSeeks(0, 0);
    }

    public void lightOn(View view){
        publish(100, 100);
        setRGBSeeks(100, 100);
    }

    public void pHueOn(View view){
        this.pHueOn = true;

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    for (int i = 0; i < 720; i+=3) {
                        if (!pHueOn) return;
                        int r = posSinWave(50, i, 0.5);
                        int g = posSinWave(50, i, 1);
                        int b = posSinWave(50, i, 2);
                        publish(r, g);
                        setRGBSeeks(r, g);
                        try { Thread.sleep(100); } catch (InterruptedException e) { e.printStackTrace(); }
                    }
                }
            }
        });
        t.start();

    }

    public int posSinWave(int amplitude, int angle, double frequency) {
        return (int)((amplitude + (amplitude * Math.sin(Math.toRadians(angle) * frequency)))/100.0*255);
    }

    public void setRGBSeeks(int red, int green){
        mRedSeek.setProgress(red);
        mGreenSeek.setProgress(green);
        //mBlueSeek.setProgress(blue);
    }

    private void updateRGBViewHolderColor(int red, int green){
        int alpha = 255; // No opacity
        int color = (alpha << 24) | (red << 16) | (green << 8);
        mRGBValueHolder.setBackgroundColor(color);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        this.pHueOn = false;
        return super.dispatchTouchEvent(ev);
    }

}
