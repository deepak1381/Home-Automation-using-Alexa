#Import all the

import RPi.GPIO as GPIO
import time
import dht11
from pubnub.pnconfiguration import PNConfiguration
from pubnub.pubnub import PubNub
from pubnub.enums import PNStatusCategory
from pubnub.callbacks import SubscribeCallback

# Initialize the Pubnub Keys
pub_key = "***************************"
sub_key = "************************"



#pw = GPIO.PWM(40,100)          #GPIO19 as PWM output, with 100Hz frequency
#pw.start(0) 

global pubnub# Pubnub Initialization
pnconfig = PNConfiguration()
pnconfig.publish_key = 'pub-c-49d05748-917f-409f-a425-8f0bc9e281c0'
pnconfig.subscribe_key = 'sub-c-1ac5c480-fab9-11e8-9488-9e80330262eb'

pubnub = PubNub(pnconfig)
#channel1 = 'alexaTrigger'
channel1 = 'phue'
pir = 36 #Assign pin 36 to PIR
led = 40 #Assign pin 10 to LED

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD) # Use physical pin numbering
GPIO.cleanup()
GPIO.setup(pir, GPIO.IN) #Setup GPIO pin PIR as input
GPIO.setup(led, GPIO.OUT) #Setup GPIO pin for LED as output


LIGHT = 18# define pin of RPi on which you want to take output

class Listener(SubscribeCallback):
    
    
    def message(self, pubnub, message):   #take action based on  subscribe messages received

        #pw.ChangeDutyCycle(message.message['GREEN'])               #change duty cycle for varying the brightness of LED.
        #time.sleep(0.01)
        print("hello")
        print(message.message['RED'])
        
        if message.message['RED'] == 100:
            print(' ON Button pressed...')
            GPIO.output(led, GPIO.HIGH) # Turn on
            
           # pubnub.add_listener(Listener())
           # pubnub.publish().channel("phue").message({'fieldA': 'On Pressed', 'fieldB': 10}).sync()
            time.sleep(0.5)
            
        elif message.message['RED'] == 0:
            print('OFF Button pressed...')
            GPIO.output(led, GPIO.LOW) # Turn on
            
          #  pubnub.add_listener(Listener())
           #S pubnub.publish().channel("phue").message({'fieldA': 'Off Pressed', 'fieldB': 0}).sync()
            
            time.sleep(0.5)
        
        
print('Listening...')
pubnub.add_listener(Listener())
#pubnub.publish().channel("phue").message({'fieldA': 'Raspdata sent by Deepak before subscribe', 'fieldB': 10}).sync()
 
pubnub.subscribe().channels(channel1).execute()





def init():
  #GPIO.setmode(GPIO.BCM)
  GPIO.setwarnings(False)
  GPIO.setup(LIGHT, GPIO.OUT)
  GPIO.output(LIGHT, False)# pubnub = Pubnub(publish_key = pub_key, subscribe_key = sub_key)
  #pubnub.subscribe(channels = 'alexaTrigger', callback = callback, error = callback, reconnect = reconnect, disconnect = disconnect)


def control_alexa(controlCommand):
  if (controlCommand.has_key("trigger")):
    if (controlCommand["trigger"] == "light"
      and controlCommand["status"] == 1):
      GPIO.output(LIGHT, True)
      print("light is on")
    else:
        GPIO.output(LIGHT, False)
        print("light is off")
  else :
      pass

def callback(message, channel):
    if (message.has_key("requester")):
        control_alexa(message)
    else :
        pass

def error(message):
  print("ERROR : " + str(message))

def reconnect(message):
    print("RECONNECTED")
def disconnect(message):
    print("DISCONNECTED")

if __name__ == '__main__':
  init()# Initialize the Script