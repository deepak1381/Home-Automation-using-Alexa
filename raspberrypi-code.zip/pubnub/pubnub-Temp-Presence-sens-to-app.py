import RPi.GPIO as GPIO
import dht11
import I2C_LCD_driver
import time

from pubnub.pnconfiguration import PNConfiguration
from pubnub.pubnub import PubNub
from pubnub.enums import PNStatusCategory
from pubnub.callbacks import SubscribeCallback



GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD) # Use physical pin numbering
GPIO.cleanup()

pir = 36 #Assign pin 36 to PIR
led = 40 #Assign pin 10 to LED
GPIO.setup(pir, GPIO.IN) #Setup GPIO pin PIR as input
GPIO.setup(led, GPIO.OUT) #Setup GPIO pin for LED as output

#GPIO.setup(40, GPIO.OUT, initial=GPIO.LOW) # Set pin 40 to be an output pin and set initial value to low (off)

mylcd = I2C_LCD_driver.lcd()

pnconfig = PNConfiguration()
pnconfig.publish_key = 'pub-c-49d05748-917f-409f-a425-8f0bc9e281c0'
pnconfig.subscribe_key = 'sub-c-1ac5c480-fab9-11e8-9488-9e80330262eb'

pubnub = PubNub(pnconfig)
channel1 = 'phue'
channel2 = 'deepak'
motion= False
smoke=False

class Listener(SubscribeCallback):
    
    
    def message(self, pubnub, message):   #take action based on  subscribe messages received
#        print(message.message['RED'])
        if message.message['RED'] == 255:
            print(' ON Button pressed...')
            GPIO.output(led, GPIO.HIGH) # Turn on
            
           # pubnub.add_listener(Listener())
           # pubnub.publish().channel("phue").message({'fieldA': 'On Pressed', 'fieldB': 10}).sync()
            time.sleep(1)
            
        elif message.message['RED'] == 0:
            print('OFF Button pressed...')
            GPIO.output(led, GPIO.LOW) # Turn on
            
          #  pubnub.add_listener(Listener())
           #S pubnub.publish().channel("phue").message({'fieldA': 'Off Pressed', 'fieldB': 0}).sync()
            
            time.sleep(1)
        
        
print('Listening...')
pubnub.add_listener(Listener())
#pubnub.publish().channel("phue").message({'fieldA': 'Raspdata sent by Deepak before subscribe', 'fieldB': 10}).sync()
 
pubnub.subscribe().channels(channel1).execute()


str_pad = " " * 16
my_long_string = "IOT Based Secured Home Automation"
my_long_string = str_pad + my_long_string

for i in range (0, len(my_long_string)):
 lcd_text = my_long_string[i:(i+16)]
 mylcd.lcd_display_string(lcd_text,1)
 time.sleep(0.01)
 mylcd.lcd_display_string(str_pad,1)
 
time.sleep(2)
mylcd.lcd_clear()

while True:
  
  instance = dht11.DHT11(pin = 11)   #gpio 17
  result = instance.read()
  motion=False

# Uncomment for Fahrenheit:
# result.temperature = (result.temperature * 1.8) + 32 

  if result.is_valid():
    
      mylcd.lcd_display_string("Temp: %d%s C" % (result.temperature, chr(223)), 1)
      time.sleep(1)
      mylcd.lcd_clear()
      mylcd.lcd_display_string("Humidity: %d %%" % result.humidity, 2)
      time.sleep(0.5)
     # pubnub.publish().channel("deepak").message({'humi': result.humidity,'temp': result.temperature}).sync()
      print(result.temperature)
    
  if GPIO.input(pir) == True: #If PIR pin goes high, motion is detected
      print ("Motion Detected!")
      motion=True
      GPIO.output(led, True) #Turn on LED
      time.sleep(0.5) #Keep LED on for 4 seconds
      GPIO.output(led, False) #Turn off LED
      time.sleep(5)
      
      

  pubnub.publish().channel("deepak").message({'humi': result.humidity,'temp': result.temperature, 'motion': motion,'smoke':smoke}).sync()    
      
      


      
      
