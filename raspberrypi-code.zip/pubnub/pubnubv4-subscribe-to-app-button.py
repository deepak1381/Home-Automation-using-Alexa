from pubnub.pnconfiguration import PNConfiguration
from pubnub.pubnub import PubNub
from pubnub.enums import PNStatusCategory
from pubnub.callbacks import SubscribeCallback

#################################################

import RPi.GPIO as GPIO # Import Raspberry Pi GPIO library
from time import sleep # Import the sleep function from the time module
GPIO.setwarnings(False) # Ignore warning for now
GPIO.setmode(GPIO.BOARD) # Use physical pin numbering
GPIO.setup(40, GPIO.OUT, initial=GPIO.LOW) # Set pin 40 to be an output pin and set initial value to low (off)



pnconfig = PNConfiguration()

pnconfig.publish_key = 'pub-c-49d05748-917f-409f-a425-8f0bc9e281c0'
pnconfig.subscribe_key = 'sub-c-1ac5c480-fab9-11e8-9488-9e80330262eb'

pubnub = PubNub(pnconfig)
 

channel = 'phue'

class Listener(SubscribeCallback):
    
    
    def message(self, pubnub, message):   #take action based on  subscribe messages received
#        print(message.message['RED'])
        if message.message['RED'] == 255:
            print(' ON Button pressed...')
        elif message.message['RED'] == 255:
            print(' ON Button pressed...')
            GPIO.output(40, GPIO.HIGH) # Turn on
            
           # pubnub.add_listener(Listener())
           # pubnub.publish().channel("phue").message({'fieldA': 'On Pressed', 'fieldB': 10}).sync()
            sleep(1)
            
        elif message.message['RED'] == 0:
            print('OFF Button pressed...')
            GPIO.output(40, GPIO.LOW) # Turn on
            
          #  pubnub.add_listener(Listener())
           #S pubnub.publish().channel("phue").message({'fieldA': 'Off Pressed', 'fieldB': 0}).sync()
            
            sleep(1)
            
    
 
        

print('Listening...')
pubnub.add_listener(Listener())
pubnub.publish().channel("phue").message({'fieldA': 'Raspdata sent by Deepak before subscribe', 'fieldB': 10}).sync()
 
pubnub.subscribe().channels(channel).execute()



