import time
import I2C_LCD_driver
mylcd = I2C_LCD_driver.lcd()

while True:
    mylcd.lcd_display_string("Cisco Systems", 1, 2)
    time.sleep(1)
    mylcd.lcd_display_string("Temp 19 C", 2, 2)
    time.sleep(1)
    mylcd.lcd_clear()
    time.sleep(1)
    
