import RPi.GPIO as GPIO
import dht11
import I2C_LCD_driver
import time 

mylcd = I2C_LCD_driver.lcd()

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.cleanup()

str_pad = " " * 16
my_long_string = "IOT Based Secured Home Automation"
my_long_string = str_pad + my_long_string

for i in range (0, len(my_long_string)):
 lcd_text = my_long_string[i:(i+16)]
 mylcd.lcd_display_string(lcd_text,1)
 time.sleep(0.01)
 mylcd.lcd_display_string(str_pad,1)
 


time.sleep(2)
mylcd.lcd_clear()

while True:
  
  instance = dht11.DHT11(pin = 17)   #gpio 17
  result = instance.read()

# Uncomment for Fahrenheit:
# result.temperature = (result.temperature * 1.8) + 32 

  if result.is_valid():

    mylcd.lcd_display_string("Temp: %d%s C" % (result.temperature, chr(223)), 1)
    time.sleep(1)
    mylcd.lcd_clear()
    mylcd.lcd_display_string("Humidity: %d %%" % result.humidity, 2)
    time.sleep(0.5)
   
