#Import the Modules Required
import RPi.GPIO as GPIO
import time

from pubnub.pnconfiguration import PNConfiguration
from pubnub.pubnub import PubNub
from pubnub.enums import PNStatusCategory
from pubnub.callbacks import SubscribeCallback

# Initialize the Pubnub Keys 
pnconfig = PNConfiguration()
pnconfig.publish_key = 'pub-c-49d05748-917f-409f-a425-8f0bc9e281c0'
pnconfig.subscribe_key = 'sub-c-1ac5c480-fab9-11e8-9488-9e80330262eb'

pubnub = PubNub(pnconfig)

LIGHT = 21

class Listener(SubscribeCallback):
    
    
    def message(self, pubnub, message):   #take action based on  subscribe messages received
        print(message.message['trigger'])
        alexaControl(message)
        
        



'''****************************************************************************************
Function Name 	:	init
Description		:	Initalize the pubnub keys and Starts Subscribing 
Parameters 		:	None
****************************************************************************************'''
def init():
	#Pubnub Initialization
	global pubnub
	GPIO.setmode(GPIO.BCM)
	GPIO.setwarnings(False)
	GPIO.setup(LIGHT,GPIO.OUT)
	GPIO.output(LIGHT, False)
	pubnub.add_listener(Listener())
	pubnub.subscribe().channels('alexaTrigger').execute()
	
	#pubnub = Pubnub(publish_key=g_pub_key,subscribe_key=g_sub_key)
	#pubnub.subscribe(channels='alexaTrigger', callback=callback, error=callback, reconnect=reconnect, disconnect=disconnect)

'''****************************************************************************************
Function Name 	:	alexaControl
Description		:	Alexa Control, commands received and action performed  
Parameters 		:	controlCommand
****************************************************************************************'''
def alexaControl(message):
    #if key in dict.keys(): 
	if ("trigger" in message.message):
		if(message.message["trigger"] == "light" and message.message["status"] == 1):
			GPIO.output(LIGHT, True) 
			print("light on successfully")
		else:
			GPIO.output(LIGHT, False) 
			print("light off")
	else:
		pass


'''****************************************************************************************
Function Name 	:	callback
Description		:	Waits for the message from the alexaTrigger channel
Parameters 		:	message - Sensor Status sent from the hardware
					channel - channel for the callback
****************************************************************************************'''
def callback(message, channel):
	if(message.has_key("requester")):
		alexaControl(message)
	else:
		pass

'''****************************************************************************************
Function Name 	:	error
Description		:	If error in the channel, prints the error
Parameters 		:	message - error message
****************************************************************************************'''
def error(message):
    print("ERROR : " + str(message))

'''****************************************************************************************
Function Name 	:	reconnect
Description		:	Responds if server connects with pubnub
Parameters 		:	message
****************************************************************************************'''
def reconnect(message):
    print("RECONNECTED")

'''****************************************************************************************
Function Name 	:	disconnect
Description		:	Responds if server disconnects from pubnub
Parameters 		:	message
****************************************************************************************'''
def disconnect(message):
    print("DISCONNECTED")

'''****************************************************************************************
Function Name 	:	__main__
Description		:	Conditional Stanza where the Script starts to run
Parameters 		:	None
****************************************************************************************'''
if __name__ == '__main__':
	#Initialize the Script
	init()

#End of the Script 
##*****************************************************************************************************##